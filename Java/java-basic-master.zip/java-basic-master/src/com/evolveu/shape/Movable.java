package com.evolveu.shape;

public interface Movable {

    public void moveUp(int distance);

    public void moveDown(int distance);

}
