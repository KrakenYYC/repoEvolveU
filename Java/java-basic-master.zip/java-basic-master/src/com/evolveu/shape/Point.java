package com.evolveu.shape;

public abstract class Point extends Object {

    public Point() {
        System.out.println("In Point Constructor");
    }

    public String doSomething() {
        return "stuff";
    }

}
