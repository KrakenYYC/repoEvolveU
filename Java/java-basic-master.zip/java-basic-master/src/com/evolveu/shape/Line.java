package com.evolveu.shape;

public abstract class Line extends Point {

    public Line() {
        System.out.println("In Line Constructor");
    }

    public String doSomething() {
        return "stuff";
    }

}
